import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Video, 
  BarChart3, 
  Cpu, 
  Bell, 
  Search, 
  Settings, 
  ShieldCheck, 
  TrendingUp, 
  TrendingDown, 
  Activity,
  Zap,
  HardDrive,
  Database,
  History,
  Download,
  Filter,
  EyeOff,
  AlertTriangle,
  Info,
  User,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { Card, CardHeader, CardContent, Badge } from './components/UI';
import { cn } from './lib/utils';

// Mock Data
const timelineData = [
  { time: '08:00', pods: 20, target: 40 },
  { time: '10:00', pods: 25, target: 40 },
  { time: '12:00', pods: 35, target: 40 },
  { time: '14:00', pods: 22, target: 40 },
  { time: '16:00', pods: 42, target: 40 },
  { time: '18:00', pods: 40, target: 40 },
];

const benchmarkData = [
  { name: 'v7', map: 78.4, latency: 25, accuracy: 88.2 },
  { name: 'v10', map: 85.1, latency: 18, accuracy: 92.4 },
  { name: 'v11', map: 89.2, latency: 12, accuracy: 94.5 },
];

const eventLogs = [
  { id: 'EV-9402', timestamp: 'Oct 27, 14:23:01', location: 'North Entrance', type: 'Unauthorized Access', confidence: '99.4%', status: 'secured' },
  { id: 'EV-9388', timestamp: 'Oct 27, 11:05:44', location: 'Main Lobby', type: 'Crowd Anomaly', confidence: '87.2%', status: 'secured' },
  { id: 'EV-9351', timestamp: 'Oct 26, 23:51:12', location: 'Loading Dock B', type: 'Vehicle Identified', confidence: '94.1%', status: 'archived' },
  { id: 'EV-9210', timestamp: 'Oct 26, 18:30:00', location: 'West Corridor', type: 'Maintenance', confidence: '92.0%', status: 'secured' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'streams', label: 'Live Streams', icon: Video },
    { id: 'analysis', label: 'Deep Analysis', icon: BarChart3 },
    { id: 'models', label: 'AI Models', icon: Cpu },
    { id: 'alerts', label: 'Alerts', icon: Bell },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100">
      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-background-dark border-r border-slate-200 dark:border-slate-800 transition-transform duration-300 lg:relative lg:translate-x-0",
          !isSidebarOpen && "-translate-x-full lg:hidden"
        )}
      >
        <div className="p-6 flex items-center gap-3">
          <div className="p-2 bg-primary rounded-lg">
            <Activity className="text-white size-5" />
          </div>
          <h1 className="font-bold text-xl tracking-tight">VisionPro AI</h1>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 px-3">System</p>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
                activeTab === item.id 
                  ? "bg-primary/10 text-primary font-semibold shadow-sm" 
                  : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              )}
            >
              <item.icon className="size-5" />
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 m-4 bg-slate-100 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase">System Status</span>
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </div>
          <div className="space-y-3">
            <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
              <div className="bg-primary h-full w-[72%]"></div>
            </div>
            <p className="text-[10px] text-slate-400">72% GPU Utilization • Node-04</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-8 bg-white/80 dark:bg-background-dark/50 backdrop-blur-md z-40">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              <Menu className="size-5" />
            </button>
            <h2 className="text-lg font-semibold capitalize">{activeTab.replace('-', ' ')}</h2>
            <Badge variant="success">Live</Badge>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 size-4" />
              <input 
                className="pl-10 pr-4 py-1.5 rounded-lg border-none bg-slate-100 dark:bg-slate-800 text-sm focus:ring-2 focus:ring-primary w-64 outline-none" 
                placeholder="Search events or nodes..." 
                type="text"
              />
            </div>
            <div className="flex items-center gap-3">
              <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg relative transition-colors">
                <Bell className="size-5 text-slate-600 dark:text-slate-300" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-white dark:border-background-dark"></span>
              </button>
              <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
                <Settings className="size-5 text-slate-600 dark:text-slate-300" />
              </button>
              <div className="h-8 w-8 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
                <img 
                  className="w-full h-full object-cover" 
                  src="https://picsum.photos/seed/user/100/100" 
                  alt="User profile" 
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
          {activeTab === 'dashboard' && (
            <>
              {/* Stats Grid */}
              <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="p-5 border-l-4 border-l-primary">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-xs font-medium uppercase">GPU Cluster</span>
                    <Cpu className="size-4 text-primary" />
                  </div>
                  <div className="flex items-end justify-between">
                    <h3 className="text-2xl font-bold">12 Active</h3>
                    <span className="text-emerald-500 text-xs flex items-center gap-1 font-semibold mb-1">
                      <TrendingUp className="size-3" /> 4%
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2">NVIDIA A100-SXM4 x 48</p>
                </Card>

                <Card className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-xs font-medium uppercase">Inference Load</span>
                    <Zap className="size-4 text-amber-500" />
                  </div>
                  <div className="flex items-end justify-between">
                    <h3 className="text-2xl font-bold">4.2ms</h3>
                    <span className="text-slate-400 text-xs mb-1">Avg Latency</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-1 rounded-full mt-3">
                    <div className="bg-primary h-full w-2/3 rounded-full"></div>
                  </div>
                </Card>

                <Card className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-xs font-medium uppercase">Throughput</span>
                    <Activity className="size-4 text-emerald-500" />
                  </div>
                  <div className="flex items-end justify-between">
                    <h3 className="text-2xl font-bold">128k/s</h3>
                    <Badge variant="success">Stable</Badge>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2">9 Nodes Online • Queue Clear</p>
                </Card>

                <Card className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-slate-500 text-xs font-medium uppercase">Storage Health</span>
                    <HardDrive className="size-4 text-blue-500" />
                  </div>
                  <div className="flex items-end justify-between">
                    <h3 className="text-2xl font-bold">82%</h3>
                    <span className="text-amber-500 text-xs font-semibold mb-1">High Load</span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-800 h-1 rounded-full mt-3">
                    <div className="bg-amber-500 h-full w-[82%] rounded-full"></div>
                  </div>
                </Card>
              </section>

              {/* Main Charts Section */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
                {/* Scaling Timeline */}
                <Card className="xl:col-span-8 p-6">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-lg font-bold">KEDA Pod Scaling Timeline</h3>
                      <p className="text-xs text-slate-500">Real-time pod count vs request volume</p>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-primary"></div>
                        <span className="text-xs text-slate-500">Pods</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-700"></div>
                        <span className="text-xs text-slate-500">Target</span>
                      </div>
                    </div>
                  </div>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={timelineData}>
                        <defs>
                          <linearGradient id="colorPods" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#007fff" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#007fff" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.1} />
                        <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
                        <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '8px', fontSize: '12px' }}
                          itemStyle={{ color: '#fff' }}
                        />
                        <Area type="monotone" dataKey="pods" stroke="#007fff" strokeWidth={3} fillOpacity={1} fill="url(#colorPods)" />
                        <Area type="monotone" dataKey="target" stroke="#475569" strokeWidth={2} strokeDasharray="5 5" fill="transparent" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                {/* Detection Stats */}
                <Card className="xl:col-span-4 p-6">
                  <h3 className="text-lg font-bold mb-6">Object Detection Stats</h3>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500 font-medium">Standard Engine</span>
                        <span className="font-bold">45 req/s</span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-slate-400 h-full w-[45%]"></div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-primary font-bold">TensorRT Engine</span>
                        <span className="text-primary font-bold">182 req/s</span>
                      </div>
                      <div className="w-full bg-primary/10 h-2 rounded-full overflow-hidden">
                        <div className="bg-primary h-full w-[95%]"></div>
                      </div>
                    </div>
                    <div className="mt-8 p-4 rounded-xl bg-primary/5 border border-primary/20">
                      <div className="flex gap-3">
                        <Zap className="size-5 text-primary shrink-0" />
                        <div>
                          <p className="text-sm font-bold">Optimization Gain</p>
                          <p className="text-2xl font-black text-primary">4.04x</p>
                          <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">Dynamic batching & quantization improved throughput by 304%.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <button className="w-full mt-auto pt-6 text-sm font-semibold text-primary hover:underline flex items-center justify-center gap-1">
                    View Engine Details <ChevronRight className="size-4" />
                  </button>
                </Card>
              </div>

              {/* Live Feeds Section */}
              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">Live YOLOv11 Feeds</h3>
                  <div className="flex gap-2">
                    <button className="px-3 py-1 rounded-lg bg-primary text-white text-xs font-medium">Grid View</button>
                    <button className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 text-xs font-medium">List</button>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                  {/* Feed 1 */}
                  <div className="relative group aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900">
                    <img 
                      className="w-full h-full object-cover opacity-60 grayscale group-hover:grayscale-0 transition-all duration-700" 
                      src="https://picsum.photos/seed/city1/800/450" 
                      alt="CCTV Feed 1" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 pointer-events-none">
                      <div className="yolo-box border-emerald-400" style={{ top: '20%', left: '30%', width: '15%', height: '40%' }}>
                        <div className="yolo-label !bg-emerald-400">Pedestrian 0.98</div>
                      </div>
                      <div className="yolo-box border-primary" style={{ top: '50%', left: '60%', width: '25%', height: '30%' }}>
                        <div className="yolo-label">Vehicle 0.92</div>
                      </div>
                    </div>
                    <div className="absolute top-4 left-4 flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                      <span className="text-xs font-bold text-white drop-shadow-md">CAM-01: Main Plaza</span>
                    </div>
                    <div className="absolute bottom-4 right-4 text-[10px] text-white/70 bg-black/40 px-2 py-1 rounded">
                      FPS: 24.8 | Latency: 42ms
                    </div>
                  </div>

                  {/* Feed 2 */}
                  <div className="relative group aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900">
                    <img 
                      className="w-full h-full object-cover opacity-60 grayscale group-hover:grayscale-0 transition-all duration-700" 
                      src="https://picsum.photos/seed/city2/800/450" 
                      alt="CCTV Feed 2" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 pointer-events-none">
                      <div className="yolo-box border-amber-400" style={{ top: '10%', left: '10%', width: '8%', height: '8%' }}>
                        <div className="yolo-label !bg-amber-400">Sign: Stop 0.99</div>
                      </div>
                      <div className="yolo-box border-emerald-400" style={{ top: '40%', left: '45%', width: '10%', height: '35%' }}>
                        <div className="yolo-label !bg-emerald-400">Pedestrian 0.87</div>
                      </div>
                    </div>
                    <div className="absolute top-4 left-4 flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                      <span className="text-xs font-bold text-white drop-shadow-md">CAM-02: Crosswalk A</span>
                    </div>
                  </div>

                  {/* Feed 3 */}
                  <div className="relative group aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900">
                    <img 
                      className="w-full h-full object-cover opacity-60 grayscale group-hover:grayscale-0 transition-all duration-700" 
                      src="https://picsum.photos/seed/city3/800/450" 
                      alt="CCTV Feed 3" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 pointer-events-none">
                      <div className="yolo-box border-purple-400" style={{ top: '65%', left: '20%', width: '12%', height: '15%' }}>
                        <div className="yolo-label !bg-purple-400">Animal: Dog 0.94</div>
                      </div>
                    </div>
                    <div className="absolute top-4 left-4 flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                      <span className="text-xs font-bold text-white drop-shadow-md">CAM-03: North Residential</span>
                    </div>
                  </div>
                </div>
              </section>

              {/* Event Logs Table */}
              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">Recent Event History</h3>
                  <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium">
                    <Filter className="size-3" /> Filter
                  </button>
                </div>
                <Card className="overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 font-bold text-xs uppercase border-b border-slate-200 dark:border-slate-800">
                        <tr>
                          <th className="px-6 py-4">Event ID</th>
                          <th className="px-6 py-4">Timestamp</th>
                          <th className="px-6 py-4">Location</th>
                          <th className="px-6 py-4">Event Type</th>
                          <th className="px-6 py-4">Confidence</th>
                          <th className="px-6 py-4">Security Status</th>
                          <th className="px-6 py-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                        {eventLogs.map((log) => (
                          <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                            <td className="px-6 py-4 font-mono text-xs text-primary">{log.id}</td>
                            <td className="px-6 py-4 text-slate-500">{log.timestamp}</td>
                            <td className="px-6 py-4 font-medium">{log.location}</td>
                            <td className="px-6 py-4">
                              <Badge variant={log.type.includes('Unauthorized') ? 'danger' : 'info'}>{log.type}</Badge>
                            </td>
                            <td className="px-6 py-4 font-bold">{log.confidence}</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-1.5 text-emerald-500">
                                <ShieldCheck className="size-3.5" />
                                <span className="text-[10px] font-bold uppercase tracking-wider">{log.status}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <button className="text-slate-400 hover:text-primary transition-colors">
                                <Download className="size-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>
              </section>
            </>
          )}

          {activeTab === 'analysis' && (
            <div className="space-y-8">
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-bold tracking-tight">Detailed AI Analysis</h1>
                  <p className="text-slate-500 mt-1 text-lg">Performance comparison and privacy masking management</p>
                </div>
                <div className="flex gap-3">
                  <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-white font-medium text-sm hover:brightness-110 transition-all shadow-lg shadow-primary/20">
                    <Download className="size-4" /> Export Report
                  </button>
                </div>
              </div>

              {/* Benchmarks Section */}
              <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="p-6">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <p className="text-sm text-slate-500 font-medium uppercase tracking-wider">Mean Average Precision (mAP)</p>
                      <h3 className="text-3xl font-bold text-primary mt-1">89.2% <span className="text-xs text-emerald-500 font-normal ml-1">+4.2%</span></h3>
                    </div>
                    <Activity className="text-slate-400 size-5" />
                  </div>
                  <div className="h-40 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={benchmarkData}>
                        <Bar dataKey="map" radius={[4, 4, 0, 0]}>
                          {benchmarkData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 2 ? '#007fff' : '#94a3b8'} fillOpacity={index === 2 ? 1 : 0.4} />
                          ))}
                        </Bar>
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <p className="text-sm text-slate-500 font-medium uppercase tracking-wider">Inference Latency</p>
                      <h3 className="text-3xl font-bold text-primary mt-1">12ms <span className="text-xs text-emerald-500 font-normal ml-1">-15%</span></h3>
                    </div>
                    <Zap className="text-slate-400 size-5" />
                  </div>
                  <div className="h-40 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={benchmarkData}>
                        <Bar dataKey="latency" radius={[4, 4, 0, 0]}>
                          {benchmarkData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 2 ? '#007fff' : '#94a3b8'} fillOpacity={index === 2 ? 1 : 0.4} />
                          ))}
                        </Bar>
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <p className="text-sm text-slate-500 font-medium uppercase tracking-wider">Classification Accuracy</p>
                      <h3 className="text-3xl font-bold text-primary mt-1">94.5% <span className="text-xs text-emerald-500 font-normal ml-1">+2.1%</span></h3>
                    </div>
                    <ShieldCheck className="text-slate-400 size-5" />
                  </div>
                  <div className="h-40 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={benchmarkData}>
                        <Bar dataKey="accuracy" radius={[4, 4, 0, 0]}>
                          {benchmarkData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 2 ? '#007fff' : '#94a3b8'} fillOpacity={index === 2 ? 1 : 0.4} />
                          ))}
                        </Bar>
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              </section>

              {/* Privacy Masking Engine */}
              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <EyeOff className="text-primary size-5" />
                    <h2 className="text-xl font-bold">Privacy Masking Engine</h2>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/20 rounded-full">
                    <span className="size-2 rounded-full bg-primary animate-pulse"></span>
                    <span className="text-xs font-bold text-primary uppercase tracking-wider">Processing</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="aspect-video relative overflow-hidden group">
                    <div className="absolute top-4 left-4 z-10 bg-black/60 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-white uppercase tracking-widest border border-white/20">Original Feed</div>
                    <img 
                      className="w-full h-full object-cover opacity-80" 
                      src="https://picsum.photos/seed/street/1280/720" 
                      alt="Original street feed" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-1/4 left-1/3 w-16 h-24 border-2 border-red-500 bg-red-500/10">
                      <span className="absolute -top-5 left-0 bg-red-500 text-white text-[8px] px-1 font-bold">Person 98%</span>
                    </div>
                  </Card>
                  <Card className="aspect-video relative overflow-hidden border-2 border-primary/30 shadow-xl shadow-primary/5">
                    <div className="absolute top-4 left-4 z-10 bg-primary/80 backdrop-blur px-2 py-1 rounded text-[10px] font-bold text-white uppercase tracking-widest border border-white/20">Privacy Mode Active</div>
                    <img 
                      className="w-full h-full object-cover blur-[4px] opacity-80" 
                      src="https://picsum.photos/seed/street/1280/720" 
                      alt="Masked street feed" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-[28%] left-[34.5%] w-12 h-12 bg-white/20 backdrop-blur-xl rounded-full border border-white/30"></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-background-dark/40 to-transparent"></div>
                  </Card>
                </div>
              </section>
            </div>
          )}

          {activeTab === 'alerts' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Active Alerts</h2>
                  <Badge variant="danger">3 New</Badge>
                </div>
                
                <div className="space-y-4">
                  <Card className="p-6 border-l-4 border-l-red-500 bg-red-500/5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex gap-4">
                        <div className="p-3 bg-red-500/20 rounded-xl text-red-500">
                          <AlertTriangle className="size-6" />
                        </div>
                        <div>
                          <h4 className="text-lg font-bold text-red-500">Critical Crowd Density</h4>
                          <p className="text-xs text-slate-500">Zone A-12 • Just now</p>
                        </div>
                      </div>
                      <Badge variant="danger">Critical</Badge>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mb-6">Density exceeded 6 people/m². High risk of crushing detected at crosswalk bottleneck.</p>
                    <div className="flex gap-3">
                      <button className="flex-1 bg-red-500 hover:bg-red-600 text-white font-bold py-2.5 rounded-xl transition-all">Dispatch Response</button>
                      <button className="px-4 py-2.5 border border-red-500/20 rounded-xl text-red-500 hover:bg-red-500/10 transition-all">
                        <Video className="size-5" />
                      </button>
                    </div>
                  </Card>

                  <Card className="p-6 border-l-4 border-l-amber-500 bg-amber-500/5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex gap-4">
                        <div className="p-3 bg-amber-500/20 rounded-xl text-amber-500">
                          <Activity className="size-6" />
                        </div>
                        <div>
                          <h4 className="text-lg font-bold text-amber-500">Jaywalking Pattern</h4>
                          <p className="text-xs text-slate-500">Metro West Exit • 2 mins ago</p>
                        </div>
                      </div>
                      <Badge variant="warning">Warning</Badge>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mb-6">Group of 5+ individuals crossing against signal. High intersection risk.</p>
                    <div className="flex gap-3">
                      <button className="flex-1 bg-amber-500 hover:bg-amber-600 text-white font-bold py-2.5 rounded-xl transition-all">Broadcast Warning</button>
                      <button className="px-4 py-2.5 border border-amber-500/20 rounded-xl text-amber-500 hover:bg-amber-500/10 transition-all">
                        <X className="size-5" />
                      </button>
                    </div>
                  </Card>

                  <Card className="p-6 border-l-4 border-l-primary bg-primary/5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex gap-4">
                        <div className="p-3 bg-primary/20 rounded-xl text-primary">
                          <Info className="size-6" />
                        </div>
                        <div>
                          <h4 className="text-lg font-bold text-primary">High Density Detected</h4>
                          <p className="text-xs text-slate-500">Main Plaza • 5 mins ago</p>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300">Density trend increasing by 15% per cycle. Monitoring bottleneck formation.</p>
                  </Card>
                </div>
              </div>

              <div className="space-y-6">
                <Card className="p-6 bg-primary text-white shadow-xl shadow-primary/20">
                  <h4 className="font-bold text-base mb-4 flex items-center gap-2">
                    <Zap className="size-5" /> Rapid Response
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    <button className="bg-white/20 hover:bg-white/30 backdrop-blur-md p-4 rounded-xl text-left transition-all">
                      <div className="text-[10px] font-bold opacity-70 uppercase mb-1">Police</div>
                      <div className="text-sm font-bold">Nearest Unit: 4 mins away</div>
                    </button>
                    <button className="bg-white/20 hover:bg-white/30 backdrop-blur-md p-4 rounded-xl text-left transition-all">
                      <div className="text-[10px] font-bold opacity-70 uppercase mb-1">Medical</div>
                      <div className="text-sm font-bold">On Standby: Plaza Station</div>
                    </button>
                  </div>
                  <button className="w-full mt-6 bg-white text-primary hover:bg-slate-100 font-bold py-3 rounded-xl transition-all text-sm">
                    Open Dispatch Terminal
                  </button>
                </Card>

                <Card className="p-6">
                  <h4 className="font-bold text-base mb-4">Alert Statistics</h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">Total Today</span>
                      <span className="font-bold">124</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">Resolved</span>
                      <span className="font-bold text-emerald-500">118</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-500">Avg Response Time</span>
                      <span className="font-bold">2.4 mins</span>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200 dark:border-slate-800 py-6 bg-white dark:bg-slate-900/50">
          <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2 opacity-60">
              <ShieldCheck className="size-4" />
              <span className="text-[10px] font-medium uppercase tracking-widest">VisionPro Compliance Level 4-A</span>
            </div>
            <div className="flex gap-8 text-[10px] font-bold text-slate-500 uppercase tracking-tighter">
              <a className="hover:text-primary" href="#">System Status</a>
              <a className="hover:text-primary" href="#">API Docs</a>
              <a className="hover:text-primary" href="#">Privacy Policy</a>
              <a className="hover:text-primary" href="#">Terms of Service</a>
            </div>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">© 2026 VisionPro AI Systems</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
